.. cmake-module:: ../../Modules/FindGTK.cmake
