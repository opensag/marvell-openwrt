.. cmake-module:: ../../Modules/CPackProductBuild.cmake
