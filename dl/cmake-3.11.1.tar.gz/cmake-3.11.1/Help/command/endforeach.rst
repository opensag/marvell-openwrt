endforeach
----------

Ends a list of commands in a foreach block.

::

  endforeach(expression)

See the :command:`foreach` command.
